<header class="header">
    <div class="container header__logo">
        <a href="<?php echo e(route('home')); ?>">
            <img class="header__images" src="/storage/images/logo.png" alt="logo">
        </a>

        <nav class="header__menu">
            <?php echo $__env->make('templates.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <div class="header__burger">
            <span class="header__burger_line"></span>
        </div>
        <div class="none-block">

            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a class="header__list" href="<?php echo e(route('login')); ?>">Войти</a>
                    </li>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="header__list" href="<?php echo e(route('register')); ?>">Зарегистрироваться</a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle header__list" href="#" role="button"
                       data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            Выйти
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>

        </div>
    </div>

    <nav class="header__menu_mobile header__menu_inactive">
        <?php echo $__env->make('templates.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
</header>
<?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/templates/header.blade.php ENDPATH**/ ?>