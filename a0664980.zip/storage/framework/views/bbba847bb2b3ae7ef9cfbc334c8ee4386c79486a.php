<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3>  <?php echo e(isset($article) ? ('Редактирование статьи:' . ' ' . $article->title) :  ('Создание новой статьи')); ?></h3>
            </div>
        </div>

        <div class="block-form container">
            <div class="mt-8">
                <form method="POST" enctype="multipart/form-data"
                      action="<?php echo e(isset($article) ? route('article.update', $article) : route('article.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <?php if(isset($article)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <?php if(is_int($category)): ?>
                        <input type="hidden" name="category_id" value="<?php echo e($category); ?>">
                    <?php else: ?>
                        <select class="block-form__input" name="category_id"
                                class="w-full h-12 border border-gray-800 rounded px-3">
                            <option disabled>надо выбрать категорию</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    <?php endif; ?>

                    <input name="title" type="text"
                           class="block-form__input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> block-form__input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Заголовок статьи" value="<?php echo e($article->title ?? ''); ?>"/>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input name="description" type="text"
                           class="block-form__input <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> block-form__input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Короткое описание статьи"
                           value="<?php echo e($article->description ?? ''); ?>"/>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <textarea id="editor" name="articles_body"
                              class="block-form__input <?php $__errorArgs = ['articles_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> block-form__input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              placeholder="текст статьи"
                    ><?php echo e($article->articles_body ?? ''); ?></textarea>

                    <?php $__errorArgs = ['articles_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input class="block-form__input" type="file" name="name_image">

                    <button type="submit" class="block-form__button"
                            value="save">
                        Сохранить
                    </button>
                </form>
            </div>

            
            
            
            
            
        </div>

    </main>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/NewArticle.blade.php ENDPATH**/ ?>