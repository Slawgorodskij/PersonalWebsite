<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3>  <?php echo e(isset($category) ? ('Редактирование раздела:' . ' ' . $category->title) :  ('Создание нового раздела')); ?></h3>
            </div>
        </div>

        <div class="block-form container">

            <form method="POST"
                  action="<?php echo e(isset($category) ? route('category.update', $category) : route('category.store')); ?>">
                <?php echo csrf_field(); ?>

                <?php if(isset($category)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <input name="title" type="text"
                       class="block-form__input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> block-form__input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Заголовок статьи" value="<?php echo e($category->title ?? ''); ?>"/>

                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="block-form__text-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button type="submit" class="button admin__button"
                        value="save">
                    Сохранить
                </button>
            </form>

            <a class="button admin__button" href="<?php echo e(route('category_admin')); ?>">
                <span class="transition-button__text">Назад</span>
            </a>
        </div>

    </main>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/newCategory.blade.php ENDPATH**/ ?>