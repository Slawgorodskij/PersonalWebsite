<?php $__env->startSection('content'); ?>

    <main class="main">
        <div class="introduction" data-name="<?php echo e($article->id); ?>">
            <h2 class="introduction__text container"><?php echo e($article->title); ?></h2>
        </div>

        <images id="<?php echo e($article->id); ?>"></images>

        <div class="container">

            <div class="article-body">
                <?php echo $article->articles_body; ?>

            </div>

            <a class="button admin__button" href="<?php echo e(route('category', $category)); ?>">
                <span class="transition-button__text">Назад</span>
            </a>

        </div>

    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/oneArticle.blade.php ENDPATH**/ ?>