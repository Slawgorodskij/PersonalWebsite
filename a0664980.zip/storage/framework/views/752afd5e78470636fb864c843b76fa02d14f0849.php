<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3>Просмотр отзыва <?php echo e($feedback->name); ?></h3>
            </div>
        </div>

        <div class="container">

            <h2>Обратился: <?php echo e($feedback->name); ?></h2>
            <h3>Электронная почта: <?php echo e($feedback->email); ?></h3>
            <h3>Телефон: <?php echo e($feedback->phone); ?></h3>
            <p>Текст обращения: <?php echo e($feedback->message); ?></p>

            <a class="button admin__button" href="<?php echo e(route('home_admin')); ?>">
                <span class="transition-button__text">Назад</span>
            </a>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/oneFeedback.blade.php ENDPATH**/ ?>