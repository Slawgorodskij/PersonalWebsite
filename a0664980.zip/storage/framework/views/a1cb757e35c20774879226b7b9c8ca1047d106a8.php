<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3>Просмотр статьи <?php echo e($article->title); ?></h3>
            </div>
        </div>

        <div class="container">

            <p> Фотографии статьи: </p>
            <div class="presentation container wrapper">
                <?php if(isset($images)): ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="presentation__item">
                            <img class="presentation__photo" src="/storage/images/<?php echo e($image->name_image); ?>" alt="photo">
                            <div class="presentation__hover">
                                    <h3><?php echo e($image->description); ?></h3>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <h2>Заголовок статьи: <?php echo e($article->title); ?></h2>
            <h3>Описание статьи: <?php echo e($article->description); ?></h3>
            <p> Текст статьи: </p>
            <?php echo $article->articles_body; ?>


            <form action="<?php echo e(route('article.edit', $article)); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <button class="button admin__button" type="submit">
                    <span class="transition-button__text">Перейти к редактированию статьи</span>
                </button>
            </form>

            <form action="<?php echo e(route('images.create')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <button class="button admin__button" type="submit">
                    <span class="transition-button__text">Перейти к добавлению фотографии</span>
                </button>
            </form>

            <form action="<?php echo e(route('article.destroy', $article)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="button admin__button" type="submit">
                    <span class="transition-button__text">Удалить статью</span>
                </button>
            </form>

            <a class="button admin__button" href="<?php echo e(route('article.create')); ?>">
                <span class="transition-button__text">Создать еще одну статью</span>
            </a>

            <a class="button admin__button" href="<?php echo e(route('article_admin')); ?>">
                <span class="transition-button__text">Назад на главную страницу</span>
            </a>
        </div>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/oneArticle.blade.php ENDPATH**/ ?>