<?php $__env->startSection('content'); ?>

    <main class="main">
        <div class="introduction">
            <h2 class="introduction__text container">Портфолио</h2>
        </div>

        <div class="portfolio container">
            <?php $__currentLoopData = $samples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="portfolio__item">
                    <img class="portfolio__photo" src="/storage/images/<?php echo e($sample->image); ?>" alt="">
                    <div class="portfolio__hover">
                        <h2><?php echo e($sample->title); ?></h2>
                        <p><?php echo e($sample->description); ?></p>
                        <a class="portfolio__link" href="<?php echo e($sample->link_git); ?>" target="_blank">
                            <img src="/storage/images/github.png" height="50" width="50" alt="">
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="main-block work">
            <img class="main-block__photo nature__photo" src="/storage/images/work.jpg" alt="nature">
            <div class="work__text">
                <h2 class="work__text_title">Интересна моя работа?</h2>
                <a class="work__text_link" href="<?php echo e(route('feedback.index')); ?>">Нажимай для связи</a>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/portfolio.blade.php ENDPATH**/ ?>