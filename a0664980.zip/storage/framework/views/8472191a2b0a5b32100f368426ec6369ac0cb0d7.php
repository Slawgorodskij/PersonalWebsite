

<?php $__env->startSection('content'); ?>

    <main class="main">
        <div class="introduction">
            <h2 class="introduction__text container"><?php echo e($title); ?></h2>
        </div>
        <section class="articles container">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('article', $article->id)); ?>">
                    <div class="article">
                        <div class="article__item article__photo">
                            <?php if(isset($article->image[0])): ?>
                                <img class="article__photo_img"
                                     src="/storage/images/<?php echo e($article->image[0]['name_image']); ?>" alt="">
                            <?php endif; ?>

                        </div>
                        <div class="article__item article__text">
                            <h2><?php echo e($article->title); ?></h2>
                            <p><?php echo e($article->description); ?></p>
                        </div>
                    </div>
                </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/oneCategory.blade.php ENDPATH**/ ?>