<a class="header__list" href="<?php echo e(route('about')); ?>">Обо мне</a>
<a class="header__list" href="<?php echo e(route('portfolio')); ?>">Работы</a>
<?php $__currentLoopData = $categories_for_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="header__list" href="<?php echo e(route('category', $category->id)); ?>"><?php echo e($category->title); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<a class="header__list" href="<?php echo e(route('feedback.index')); ?>">Обратная связь</a>
<?php if(Auth::user() && Auth::user()->hasRole('admin')): ?>
    <a class="header__list" href="<?php echo e(route('home_admin')); ?>">Админ</a>
<?php endif; ?>
<?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/templates/menu.blade.php ENDPATH**/ ?>