<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3><?php echo e($name_page); ?></h3>
            </div>
        </div>

        <div class="admin-main container">

            <nav class="admin-nav">
                <a class="admin-nav__text" href="<?php echo e(route('home_admin')); ?>"> Обращения </a>
                <a class="admin-nav__text" href="<?php echo e(route('article_admin')); ?>"> Статьи </a>
                <a class="admin-nav__text" href="<?php echo e(route('category_admin')); ?>"> Разделы </a>
            </nav>

            <table class="admin-table">
                <thead>
                <tr>
                    <th class="admin-table__content">Содержание</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $array_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->message??$data->description??$data->title); ?></td>
                        <td class="admin-table__block-button">

                            <a class="button admin-table__button" href="<?php echo e(route($action_button, $data)); ?>">
                                <?php echo e($button_name); ?>

                            </a>

                            <form action="<?php echo e(route($delete_button, $data)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="button admin-table__button" type="submit">Удалить</button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <?php echo e($array_data->links()); ?>


            <?php if(isset($add_button)): ?>
                <div class="button admin__button">
                    <a class="admin__button_text" href="<?php echo e($add_elem); ?>">
                        <?php echo e($add_button); ?>

                    </a>
                </div>
            <?php endif; ?>

            <?php if(isset($image_button)): ?>
                <div class="button admin__button">
                    <a class="admin__button_text" href="<?php echo e(route('images.create')); ?>">
                        <?php echo e($image_button); ?>

                    </a>
                </div>
            <?php endif; ?>

        </div>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/index.blade.php ENDPATH**/ ?>