<?php $__env->startSection('content'); ?>

    <main class="main">

        <div class="admin-performance">
            <div class="admin-performance__block container">
                <h2>Страница администратора</h2>
                <h3>Добавление фотографии</h3>
            </div>
        </div>

        <div class="block-form container">
            <form method="POST" enctype="multipart/form-data"
                  action="<?php echo e(route('images.store')); ?>">
                <?php echo csrf_field(); ?>










                <select class="block-form__input" name="article_id">
                    <option disabled>надо выбрать статью</option>
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($article->id); ?>"><?php echo e($article->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>



                <input name="description" type="text"
                       class="block-form__input <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> block-form__input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Короткое описание фотографии"/>

                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="block-form__text-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <input class="block-form__input" type="file" name="name_image">

                <button class="button admin__button" type="submit"
                        value="save">
                    Сохранить
                </button>
            </form>

            <a class="button admin__button" href="<?php echo e(route('article_admin')); ?>">
                <span class="transition-button__text">Назад</span>
            </a>

        </div>

    </main>
<?php $__env->stopSection(); ?>














<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\PersonalWebsite\resources\views/admin/addImage.blade.php ENDPATH**/ ?>