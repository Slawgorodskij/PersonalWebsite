<?php
return [
    'admin_page' => 'страница администратора',
    'set_lang' => 'en',
    'login' => 'Вход',
    'register' => 'Регистрация',
    'logout' => 'Выход из системы'
];
