<?php
return [
    'menu'=>'Меню',
    'title'=>'Главная',
    'title_category'=>'Категории новостей',
    'personal_account'=>'Личный кабинет',
];
