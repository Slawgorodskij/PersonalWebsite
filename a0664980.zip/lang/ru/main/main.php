<?php
return [
    'title'=>'Славные новости',
];

