<?php
return [
    'button_transition' => 'Перейти к разделам',
    'button_back_home' => 'Перейти на Главную страницу',
    'button_back_section' => 'Вернуться в раздел',
    'button_share' => 'поделитесь мнением.',
    'button_send' => 'Отправить',
    'button_back_news' => 'Вернуться к статье',
    'button_login' => 'Авторизоваться',
    'button_save' => 'Сохранить',
    'button_vk' => 'ВКонтакте',
    'button_fb' => 'Facebook',

];
